package com.example.calculatorapp

import  android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

@Suppress("NAME_SHADOWING")
class MainActivity : AppCompatActivity() {

    // Initialize references to UI components
    private lateinit var num1EditText: EditText
    private lateinit var num2EditText: EditText
    private lateinit var resultTextView: TextView
    private lateinit var buttonPlus: Button
    private lateinit var buttonMinus: Button
    private lateinit var buttonMultiply: Button
    private lateinit var buttonDivide: Button
    private lateinit var buttonClear: Button

    @SuppressLint("CutPasteId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Initialize ui components
        num1EditText = findViewById(R.id.num1editTextNumber)
        num2EditText = findViewById(R.id.num2editTextNumber)
        resultTextView = findViewById(R.id.editTextNumber)
        buttonPlus = findViewById(R.id.buttonPlus)
        buttonMinus = findViewById(R.id.buttonMinus)
        buttonMultiply = findViewById(R.id.buttonMultiply)
        buttonDivide = findViewById(R.id.buttonDivide)
        buttonClear = findViewById(R.id.buttonClear)

        // Set click listeners for operation buttons
        buttonPlus.setOnClickListener {

            val num1 = num1EditText.text.toString().toInt()
            val num2 = num2EditText.text.toString().toInt()

            addition(num1, num2)
        }

        buttonMinus.setOnClickListener {

            val num1 = num1EditText.text.toString().toInt()
            val num2 = num2EditText.text.toString().toInt()

            subtraction(num1, num2)
        }

        buttonMultiply.setOnClickListener {

            val num1 = num1EditText.text.toString().toInt()
            val num2 = num2EditText.text.toString().toInt()

            multiplication(num1, num2)
        }

        buttonDivide.setOnClickListener {

            val num1 = num1EditText.text.toString().toInt()
            val num2 = num2EditText.text.toString().toInt()

            division(num1, num2)
        }

        // Set click listener for clear button
        val clearbutton = findViewById<Button>(R.id.buttonClear)
        clearbutton.setOnClickListener {
            num1EditText.setText("")
            num2EditText.setText("")
            resultTextView.text = ""

            Toast.makeText(this, "cleared", Toast.LENGTH_LONG).show()
        }
    }

    // Perform addition operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun addition(num1: Int, num2: Int) {
    val result = num1 + num2
    resultTextView.text = "Result: $num1 + $num2 = $result"
    }

    // Perform subtraction operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun subtraction(num1: Int, num2: Int){
    val result = num1 - num2
    resultTextView.text = "Result: $num1 - $num2 = $result"
    }

    // Perform multiplication operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun multiplication(num1: Int, num2: Int) {
    val result = num1 * num2
    resultTextView.text = "Result: $num1 * $num2 = $result"
    }

    // Perform division operation and update resultTextView
    @SuppressLint("SetTextI18n")
    private fun division(num1: Int, num2: Int) {
    val result = if (num2 != 0) num1 / num2 else Double.NaN.toInt()
    resultTextView.text = "Result: $num1 / $num2 = $result"
    }
}